-- ---------------------------------------------------------
--
-- SIMPLE SQL Dump
-- 
-- http://www.nawa.me/
--
-- Host Connection Info: sql13.dnsserver.eu via TCP/IP
-- Generation Time: March 06, 2016 at 23:50 PM ( Europe/Bratislava )
-- PHP Version: 5.5.30
--
-- ---------------------------------------------------------


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ---------------------------------------------------------
--
-- Table structure for table : `contact_means`
--
-- ---------------------------------------------------------
CREATE TABLE `contact_means` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_baskets`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_baskets` (
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`item_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `eshop_baskets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `eshop_users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `eshop_baskets_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `eshop_items` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_categories`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_categories` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `super_cat` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `super_cat` (`super_cat`),
  CONSTRAINT `eshop_categories_ibfk_1` FOREIGN KEY (`super_cat`) REFERENCES `eshop_categories` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eshop_categories`
--
INSERT INTO `eshop_categories` (`ID`, `name`, `super_cat`) VALUES
(1, 'Drinks', ''),
(2, 'Food', ''),
(3, 'Cola drinks', 1),
(4, 'Lemon-flavored drinks', 1),
(5, 'Orange-flavored drinks', 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_ci_sessions`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eshop_ci_sessions`
--
INSERT INTO `eshop_ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('016c3ad1bdf1b1b888208d6885751570c2e12c84', '89.143.15.130', 1453317280, '__ci_last_regenerate|i:1453317085;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('07e837b0f465fe401c0a6d6ff3055e9715071b03', '89.143.15.130', 1453308498, '__ci_last_regenerate|i:1453308245;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('0d252518907fadb3814083ccfec6accce258dfa9', '89.143.15.130', 1453323226, '__ci_last_regenerate|i:1453323217;'),
('0f9f5e5d89fdc6b40c8507c6b28fe0683cf0e5b9', '89.143.15.130', 1453314039, '__ci_last_regenerate|i:1453313745;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('1721a5c2fe79bd3ddd0818f4b4789475dd4d8c32', '89.143.15.130', 1453317736, '__ci_last_regenerate|i:1453317565;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('1c211909a9e8684eb1637ecfd7a3f740f12b1e77', '89.143.15.130', 1453323340, '__ci_last_regenerate|i:1453323340;'),
('1d56ee27019e74c605f8f1b5351bcee160a7299c', '31.13.110.108', 1453327665, '__ci_last_regenerate|i:1453327665;'),
('27ed625b935986b4cb676954dfc4ab47169187d6', '89.143.15.130', 1453824912, '__ci_last_regenerate|i:1453824912;'),
('2af0cf21dd08d64bc45fe5ba6ef40c3213e6f86a', '89.143.15.130', 1453320394, '__ci_last_regenerate|i:1453320160;'),
('2e52396538494597628466c2b050457f1f8523c1', '89.143.15.130', 1453329458, '__ci_last_regenerate|i:1453329458;'),
('34deb6cfbe5f331a5c4d293350377c06892dec91', '79.248.250.109', 1453333410, '__ci_last_regenerate|i:1453333372;'),
('3839659640680f4d92a48721063dc2859c2a73d4', '89.143.15.130', 1453317003, '__ci_last_regenerate|i:1453316729;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('4058841925c0214f4c674d4a2caf68db0394ad72', '89.143.15.130', 1453319618, '__ci_last_regenerate|i:1453319479;'),
('4bfd0f08a45effc2a46de970501f3dff7cbd2ff9', '89.143.15.130', 1453312233, '__ci_last_regenerate|i:1453311933;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('53142649adbf47f00a20f126f59e0a2fc7a1f471', '89.143.15.130', 1453322036, '__ci_last_regenerate|i:1453321876;'),
('5bb528e9671c61e8e704bb5b7c56040061d80247', '89.143.15.130', 1453315663, '__ci_last_regenerate|i:1453315385;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('620ff00c785301fe30c5c885a92ac934c1cbbde6', '89.143.15.130', 1453315857, '__ci_last_regenerate|i:1453315712;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('64214530ba6e85983f81bde2e3f831b8202a7b5b', '89.143.15.130', 1453310241, '__ci_last_regenerate|i:1453309947;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('654e80de25aff2b17b6a62496fae6cdd39d0c7c5', '164.8.208.131', 1453322626, '__ci_last_regenerate|i:1453322626;'),
('6bef04d1cbac5c093ff6687ac50a9b379152b9e7', '89.143.15.130', 1453310543, '__ci_last_regenerate|i:1453310543;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('6d11a3468ad1567f3e820c9d1a524847e83f6b43', '89.143.15.130', 1453322505, '__ci_last_regenerate|i:1453322319;'),
('6ec9aff2a03e0e2781fad1d61f79f5f09353c8a0', '89.143.15.130', 1453309860, '__ci_last_regenerate|i:1453309565;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('78a792bcdb108a6733ac3f646b0b142a89f3a8f6', '89.143.15.130', 1453371550, '__ci_last_regenerate|i:1453371546;'),
('80df6f193b132ad28ce0d90ab4c7d65968c62af7', '89.143.15.130', 1453370618, '__ci_last_regenerate|i:1453370599;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('97784babc94b6ddfa7159320bbaac3e229f8919b', '89.143.15.130', 1453312371, '__ci_last_regenerate|i:1453312261;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('98e82d563a5d77eaa99a2a0f339e5b2f8db120c2', '89.143.15.130', 1453308232, '__ci_last_regenerate|i:1453307935;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('a524c91953139bda14a7f4414718d9db7c379843', '89.143.15.130', 1453321130, '__ci_last_regenerate|i:1453320947;'),
('a9b0032997eea7dcb0ec52e4344d7557e472e0e4', '89.143.15.130', 1453314203, '__ci_last_regenerate|i:1453314096;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('aa2b8856bded5b8febd6ee25e47e2ece95f8cf7a', '89.143.15.130', 1453314715, '__ci_last_regenerate|i:1453314442;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('ad681963f1fdbf307469e5324d7da469680243cf', '89.143.15.130', 1453313696, '__ci_last_regenerate|i:1453313433;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('b12a931a5f4fbdf86ddfe38751f6da18efa74596', '89.143.15.130', 1453321823, '__ci_last_regenerate|i:1453321550;'),
('b2b13e10b1a5d12be4f53f2afb224a78a6528d56', '164.8.215.112', 1453323586, '__ci_last_regenerate|i:1453323586;'),
('b44a0318c71c8b52dab5b6465a3713cb7b40cb9e', '164.8.215.112', 1453326985, '__ci_last_regenerate|i:1453326975;'),
('b89e283491ee635719f8cabf369778dbaf725698', '89.143.15.130', 1453318334, '__ci_last_regenerate|i:1453318331;'),
('ba6890c6322334ec9d91a3e4c286e2d80f5e1687', '89.143.15.130', 1453330513, '__ci_last_regenerate|i:1453330468;'),
('baa0e190334dab72a489ee4460496ac5a50cfb7a', '89.143.15.130', 1453323924, '__ci_last_regenerate|i:1453323923;'),
('cd042bd265d7f9d5e490a4e4e4f1d647d924fb14', '89.143.15.130', 1453320001, '__ci_last_regenerate|i:1453319840;'),
('d419403ee092b5a051661580f96a8714e960f4a5', '188.121.181.97', 1453824973, '__ci_last_regenerate|i:1453824940;'),
('d478147fc0402a2898e4fd7afd0cdf66e6d2ace8', '89.143.15.130', 1453308851, '__ci_last_regenerate|i:1453308591;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('d488c0a266efdc7a2543bc843e5d158d5a21148e', '89.143.15.130', 1453328182, '__ci_last_regenerate|i:1453328075;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('d915aa4c5cadd3ac936d2e2249eff2c71f8795b8', '89.143.15.130', 1453327867, '__ci_last_regenerate|i:1453327610;'),
('e0bb6bbb93712df5e0e35953f416d4df9e8c775a', '164.8.252.42', 1454666856, '__ci_last_regenerate|i:1454666811;'),
('e42d51d7f7f1de60d5dee49386c185399bf8b0f3', '164.8.215.112', 1453323231, '__ci_last_regenerate|i:1453323212;'),
('e5e1fb21e62794ae065c3ba7e8dbd8f0ede5892b', '89.143.15.130', 1453315693, '__ci_last_regenerate|i:1453315670;'),
('e9ac1cfda629bedb5b9ac90104c4061e055e29d1', '89.143.15.130', 1453320739, '__ci_last_regenerate|i:1453320488;'),
('f286916b727762c0fece309e51539095bed2ad7c', '89.143.15.130', 1453315054, '__ci_last_regenerate|i:1453314802;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('f3fc496d07a16b937fe07fec02125d87b94d55bc', '89.143.15.130', 1453309176, '__ci_last_regenerate|i:1453308907;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('f553567221b681d601bac3093bc49b6b53aed593', '89.143.15.130', 1453322885, '__ci_last_regenerate|i:1453322777;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('f76d586070701f4560bace818c9267446858aa5b', '89.143.15.130', 1453322616, '__ci_last_regenerate|i:1453322616;'),
('f87d22d91f29d7e584e804438a9aee615d286b29', '89.143.15.130', 1453316205, '__ci_last_regenerate|i:1453316083;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}'),
('ff1c0309186da2cb81afcbc8620a8253688d9136', '89.143.15.130', 1453309482, '__ci_last_regenerate|i:1453309236;logged_in|a:2:{s:2:"id";s:1:"1";s:8:"username";s:19:"tomesaros@gmail.com";}');



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_country`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_country` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eshop_country`
--
INSERT INTO `eshop_country` (`ID`, `country`) VALUES
(1, 'Slovakia'),
(2, 'Czech Republic');



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_items`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_items` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` longtext,
  `price` float NOT NULL,
  `category_id` int(11) NOT NULL,
  `showing` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `eshop_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `eshop_categories` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eshop_items`
--
INSERT INTO `eshop_items` (`ID`, `title`, `description`, `price`, `category_id`, `showing`) VALUES
(1, 'Coca Cola 1,5L', 'This is sample description for Coke', 2, 3, 1),
(2, 'Pepsi Cola 0,5L', 'This is sample description for Pepsi', 1.8, 3, 1),
(3, 'Sprite 0,3L Glass', 'This is sample description for Sprite', 1.2, 4, 1),
(4, 'Dr. Pepper 0,5L', 'This is description for Dr. Pepper', 1.8, 3, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_log`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IP` varchar(30) DEFAULT NULL,
  `method` varchar(200) DEFAULT NULL,
  `params` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eshop_log`
--
INSERT INTO `eshop_log` (`ID`, `timestamp`, `IP`, `method`, `params`) VALUES
(1, '2016-01-19 13:49:52', '89.143.15.130', 'getUserCount', ''),
(2, '2016-01-19 13:49:56', '89.143.15.130', 'getUserCount', ''),
(3, '2016-01-19 14:00:30', '89.143.15.130', 'getAllItems', ''),
(4, '2016-01-19 14:08:57', '89.143.15.130', 'searchItems', 'title=%\ndesc=%'),
(5, '2016-01-19 14:09:32', '89.143.15.130', 'searchItems', 'title=%0%\ndesc=%'),
(6, '2016-01-19 14:14:05', '89.143.15.130', 'getUserCount', ''),
(7, '2016-01-19 14:14:13', '89.143.15.130', 'getAllItems', ''),
(8, '2016-01-19 14:14:31', '89.143.15.130', 'getAllItems', ''),
(9, '2016-01-19 14:20:40', '89.143.15.130', 'searchItems', 'title=%0%\ndesc=%'),
(10, '2016-01-21 11:13:30', '89.143.15.130', 'getUserCount', '');



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_orders`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_orders` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ordered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dispatched` timestamp NULL DEFAULT NULL,
  `completed` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `eshop_orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `eshop_users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eshop_orders`
--
INSERT INTO `eshop_orders` (`ID`, `user_id`, `ordered`, `dispatched`, `completed`) VALUES
(1, 1, '2016-01-20 13:57:48', '2016-01-20 20:23:19', '2016-01-20 20:23:46'),
(2, 1, '2016-01-20 15:02:06', '2016-01-20 20:23:50', ''),
(3, 1, '2016-01-20 15:02:27', '', ''),
(4, 1, '2016-01-20 15:03:59', '', ''),
(5, 1, '2016-01-20 15:05:25', '', '');



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_orders_items`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_orders_items` (
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`order_id`,`item_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `eshop_orders_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `eshop_orders` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `eshop_orders_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `eshop_items` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `eshop_orders_items`
--
INSERT INTO `eshop_orders_items` (`order_id`, `item_id`, `quantity`) VALUES
(1, 1, 2),
(1, 3, 4),
(4, 1, 2),
(4, 2, 1),
(4, 3, 4),
(5, 1, 2),
(5, 2, 1),
(5, 3, 4);



-- ---------------------------------------------------------
--
-- Table structure for table : `eshop_users`
--
-- ---------------------------------------------------------
CREATE TABLE `eshop_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8_slovak_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8_slovak_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_slovak_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_slovak_ci NOT NULL,
  `is_admin` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `validity_key` varchar(100) COLLATE utf8_slovak_ci DEFAULT NULL,
  `street` varchar(200) COLLATE utf8_slovak_ci DEFAULT NULL,
  `city` varchar(200) COLLATE utf8_slovak_ci NOT NULL,
  `zip` varchar(20) COLLATE utf8_slovak_ci DEFAULT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `eshop_users_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `eshop_country` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_slovak_ci;

--
-- Dumping data for table `eshop_users`
--
INSERT INTO `eshop_users` (`ID`, `first_name`, `last_name`, `email`, `password`, `is_admin`, `is_active`, `validity_key`, `street`, `city`, `zip`, `country_id`) VALUES
(1, 'Tomáš', 'Mesároš', 'tomesaros@gmail.com', 'b8c20d3ab88e11335a85f841dd1d99a6', 1, 1, '', 'Kosodrevinová 41', 'Bratislava', 82107, 1),
(2, 'Janko', 'Hrasko', 'j.hrasko@email.sk', 'heslo', 0, 0, 'val_key', 'Street', 'City', 'Zip', 2),
(3, 'fname', 'lname', 'tomesaros@gmail.co', 'b8c20d3ab88e11335a85f841dd1d99a6', 0, 1, '', 'street', 'city', 123, 2),
(7, 'Tomáš', 'Mesároš', 'tomesaros@sms-consulting.eu', 'b8c20d3ab88e11335a85f841dd1d99a6', 0, 1, 'iz7q73839p2q03naidhxh5s6wauzpv38ubz2f75ow8exb17ufo', 'Kosodrevinová 41', 'Bratislava', 821071, 1);



-- ---------------------------------------------------------
--
-- Table structure for table : `jobs`
--
-- ---------------------------------------------------------
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` int(11) NOT NULL,
  `customer` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `date` int(11) NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `declined` tinyint(1) NOT NULL,
  `done` tinyint(1) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jobs`
--
INSERT INTO `jobs` (`id`, `provider`, `customer`, `description`, `date`, `confirmed`, `declined`, `done`, `created_datetime`) VALUES
(1, 1, 1, '#DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(26, 51, 44, 'My printer wontprint', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(27, 51, 44, 'I dont know, itdoes not print', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(28, 51, 44, 'Printer wont print', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(31, 45, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(32, 44, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(33, 45, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(34, 90, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(35, 47, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(36, 48, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(37, 49, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(38, 51, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(39, 52, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(40, 53, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(41, 5, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(42, 6, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(43, 56, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(44, 61, 89, 'DEMO', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(45, 98, 97, 'I need chocolate', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(46, 98, 97, 'I need water', 0, 0, 1, 0, '2015-07-28 10:39:18'),
(47, 97, 96, 'Help, I need somebody, helpp, not just anybody', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(48, 95, 98, 'Can you please do computer', 0, 1, 0, 1, '2015-07-28 10:39:18'),
(49, 5, 51, 'I need to install Microsoft office', 0, 0, 0, 0, '2015-07-28 10:39:18'),
(50, 108, 108, 'asdfghjklasdfghjk', 0, 1, 0, 0, '2015-07-28 10:39:18'),
(51, 6, 117, 'I need help', 0, 0, 0, 0, '2015-07-28 10:39:18'),
(52, 5, 119, 'My car is bronken down can you help :)', 0, 0, 0, 0, '2015-07-28 10:39:18'),
(53, 104, 124, 'Hi Anoop. I''m looking for someone to setup my new desk top with Microsoft office and to configure new emails accounts. I also need advice about a good and efficient webmail system so I can access my email easily from other devices. Many thanks.\nAmanda', 0, 1, 0, 1, '2015-07-29 20:50:56'),
(55, 56, 126, 'Need some help installing a brand new Samsung 850 SSD and migrating data from existing HDD.', 0, 1, 0, 0, '2015-07-28 10:39:18'),
(56, 99, 51, 'Fix my phone!', 0, 0, 0, 0, '2015-07-30 10:06:31'),
(57, 99, 131, 'phone won''t phone', 0, 1, 0, 1, '2015-07-30 10:15:27'),
(58, 45, 135, 'test', 0, 0, 1, 0, '2015-09-16 18:13:14'),
(59, 45, 135, 'test', 0, 0, 1, 0, '2015-09-16 18:13:16'),
(60, 45, 135, 66, 0, 0, 1, 0, '2015-09-16 18:13:21'),
(61, 45, 44, 'i am an american   i have many problems.   we have most of the money but we have no sense.  \n\n', 0, 0, 1, 0, '2016-01-16 20:38:14'),
(62, 99, 138, 'Hi Maher, I have two laptops need repairing.\n1. Toshiba Satellite C50-A283: Power doesn''t reach the notebook. Checked wall socket, Checked the power adapter connecting to another laptop and found it is working. When connected to the main, the orange light does not come at all. Removed the battery, kept pressing the power on switch for 30-45 seconds, put the battery again and connected to the main, but no sign of power reaching the notebook.\n\n2. ASUS K56C SonicMaster: The display is distorted,', 0, 0, 0, 0, '2015-09-11 18:24:26'),
(63, 51, 144, 'Wifi connects to MacBook but the internet does not work. The wifi is working on other devices. ', 0, 0, 0, 0, '2015-11-25 17:06:22');



-- ---------------------------------------------------------
--
-- Table structure for table : `last_report`
--
-- ---------------------------------------------------------
CREATE TABLE `last_report` (
  `rdate` datetime NOT NULL,
  `fbcount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `last_report`
--
INSERT INTO `last_report` (`rdate`, `fbcount`) VALUES
('2016-03-05 23:52:29', 519);



-- ---------------------------------------------------------
--
-- Table structure for table : `migrations`
--
-- ---------------------------------------------------------
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- ---------------------------------------------------------
--
-- Table structure for table : `password_resets`
--
-- ---------------------------------------------------------
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- ---------------------------------------------------------
--
-- Table structure for table : `ratings`
--
-- ---------------------------------------------------------
CREATE TABLE `ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` int(11) NOT NULL,
  `customer` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `job` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ratings`
--
INSERT INTO `ratings` (`id`, `provider`, `customer`, `rating`, `job`) VALUES
(14, 51, 44, 5, 26),
(15, 51, 44, 5, 27),
(16, 51, 44, 5, 28),
(17, 51, 44, 5, 30),
(18, 45, 1, 5, 1),
(19, 90, 1, 4, 1),
(20, 47, 1, 5, 1),
(21, 48, 1, 5, 1),
(22, 49, 1, 4, 1),
(23, 52, 1, 3, 1),
(24, 53, 1, 4, 1),
(25, 5, 1, 4, 1),
(26, 6, 1, 5, 1),
(27, 56, 1, 4, 1),
(28, 61, 1, 5, 1),
(29, 98, 97, 5, 45),
(30, 97, 96, 5, 47),
(31, 95, 98, 5, 48),
(32, 44, 89, 3, 32),
(33, 104, 124, 5, 53),
(34, 99, 131, 5, 57);



-- ---------------------------------------------------------
--
-- Table structure for table : `users`
--
-- ---------------------------------------------------------
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `birthdate` date NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `provider` tinyint(1) NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `weekday_from` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weekday_to` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weekend_from` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weekend_to` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--
INSERT INTO `users` (`id`, `firstname`, `lastname`, `birthdate`, `email`, `password`, `provider`, `description`, `image`, `weekday_from`, `weekday_to`, `weekend_from`, `weekend_to`, `remember_token`, `created_at`, `updated_at`) VALUES
(5, 'Rajiv', 'Ravishankar', '0000-00-00', 'rajivravio@gmail.com', '$2y$10$6DVrYYacUG4/AMi9IqBoDOvCMHGgIoiv6r.Rb60t6C/TNsTxUOZR.', 1, 'Well versed in Windows, Mac, iOS, Android environments. Over two years experience in a user support role. \n\nGeneral troubleshooting and user support. Email setup, OS installation, printer troubleshooting and more. I can also help with imaging machines and replacing hardware on your computer.', 'user_54.jpg', '08:00', '20:00', '08:00', '18:00', '', '2015-07-17 14:38:23', '2015-07-18 15:16:09'),
(6, 'Noor-ul-huda', 'Admaney', '0000-00-00', 'nadmaney@gmail.com', '$2y$10$.o57weH228skf/0.EyhaYeObtUcKfFVlIpaItpaiPRiHyxOSzaAwi', 1, 'reinstalling windows, drivers installation, game installation ', 'user_55.jpg', '08:00', '20:00', '08:00', '18:00', '', '2015-07-17 15:23:57', '2015-07-17 17:11:42'),
(44, 'Tomas', 'Mesaros', '0000-00-00', 'tomesaros@gmail.com', '$2y$10$Gj7A8KMcSGDkVSpAYuCNnuW0niabGy0NBAtAzv.ekG2wAuInW7Riu', 0, 'I can repair any software problems - reinstall windows, debug code, configure wifi, or fix broken printer...', 'user_44.jpg', '08:00', '20:00', '08:00', '18:00', 'Z7rOGMzmnwmzITCfO8bc0pZ30N2tIbhAExzDPiEuxkriOhlvWEuzPsfN3C2s', '2015-07-17 07:24:34', '2015-08-28 02:40:02'),
(45, 'Karl-Martin', 'Miidu', '0000-00-00', 'karlmartin.miidu@gmail.com', '$2y$10$BZL3YWRc94PJPIiQR1caDeoKxV09xYIH24ylL7KWeADXD4bhtXb4e', 1, 'TUT Informatics student, have experiance solving different kinds of technical problems', 'user_45.png', '08:00', '20:00', '08:00', '18:00', '4EuJzFWmAtkEkpweVSvvkpisuYvonvZZwadYVRq8PFQKipIbGLeHAEtj1Unn', '2015-07-17 07:34:43', '2015-09-16 16:26:56'),
(47, 'Yasser', 'El-Sayyed', '0000-00-00', 'yelsayed@cmu.qatar.edu', '$2y$10$OrKtukdZU4bMUheSc17RoukSfP3/7hwX.Azys.pS48c/t5sfurlom', 1, 'Iphone, mac, web development', 'user_47.jpg', '08:00', '20:00', '08:00', '18:00', 'VA0GypWm8C8T5unodlehJMWChV7SqTsC3SJqXFqEHmvaF1eoyJ259RRi4pGQ', '2015-07-17 08:42:02', '2015-07-17 08:42:11'),
(48, 'Fazail', 'Ahmad', '0000-00-00', 'fazailahmad95@gmail.com', '$2y$10$GU1zd/7xzv/LDdLWvSfzzOorJzQUJBr3Y5EiSLnhXJwqtoTlVUbXe', 1, 'printers, windows, office applications', 'user_48.jpg', '08:00', '20:00', '08:00', '18:00', 'X217wsc7BEmQXJ7wwse6sd4deeDS632zbyMKeq4v1DUnm3acq2G9f9kliTuz', '2015-07-17 08:44:04', '2015-07-17 08:44:12'),
(49, 'Osama', 'Shehzad', '0000-00-00', 'mshehzad@qatar.cmu.edu', '$2y$10$XXwK1m2yVnlVqv6l9OkOPeOhF094j6VwKHKPXfJwxi2kSHMr.QBCi', 1, 'printers, windows, internet, wifi, office applications', 'user_49.jpg', '08:00', '20:00', '08:00', '18:00', 'K6RWH7pvGVuQPSP2Nx10gZD2wcYGUd0GOpwtMNNHJ3Cnv1piaJgPavlwo8CV', '2015-07-17 08:50:22', '2015-07-17 08:55:55'),
(50, 'Osama', 'Shehzad', '0000-00-00', 'mshehzad@qatar.cmu.edh', '$2y$10$UoiaH2LVs2Bu7C1Qxz2G4OX0UuYZB5LRYjsNYxDUxzBpGvMpNWRTq', 0, '', '', '08:00', '20:00', '08:00', '18:00', '', '2015-07-17 08:55:04', '2015-07-17 08:55:04'),
(51, 'Ahmed', 'Shah', '0000-00-00', 'shah1062@live.com', '$2y$10$Ci8dmBSAMzis2Ja3.Tgo..NEG1bcVC3sIr5tIkCpGXm5NOCMblFDe', 1, 'printers, wifi, internet, windows, mac, video, audio', 'user_51.jpg', '08:00', '20:00', '08:00', '18:00', 'LAZ2fFDTWGPgEJCuuKME0SW9seD8biiU2g1n13OdI89TPGDG5M3Il3H5ysmw', '2015-07-17 08:59:34', '2015-07-30 08:13:44'),
(52, 'Mohammed', 'Fituri', '0000-00-00', 'mof@qatar.cmu.edu', '$2y$10$QIS6voY3T/iRrNEPu78iTOyunhhXkDUk2G9nk4q/KIXGln54dvBMi', 1, 'mac, android, printers, wifi, hardware installation', 'user_52.jpg', '08:00', '20:00', '08:00', '18:00', 'NdMRJjBXN0LD1anIbiEVmpK89TVbLQgQjr78DNzZNwtXKo3OPHbuT0sYZSoK', '2015-07-17 09:09:57', '2015-07-17 20:42:31'),
(53, 'Musab', 'Popatia', '0000-00-00', 'mpopatia@cmu.edu', '$2y$10$S02YSoqQE6hz/diJkotU5uV6BI/ophOrBo0yIEnAxhSZw7K1aDene', 1, 'windows, office, android', '', '08:00', '20:00', '08:00', '18:00', '2nPt5mZYTnr4hkMccq0sDwngf8uqAPuJ0aIA4tBotFSYmtyiRvxG3WEnDRxp', '2015-07-17 14:09:43', '2015-07-17 15:13:01'),
(56, 'Syed', 'Mehdi', '0000-00-00', 'smehdi@qatar.cmu.edu', '$2y$10$rJfWBx6YYA9RbnLur3YdyeOtnnOGxq8ycUNpkZbGrNegsDUnIKwYe', 1, 'Mac, Windows, Printers, Wifi routers, Hardware Installation, Android & iPhone', 'user_56.jpg', '08:00', '20:00', '08:00', '18:00', '', '2015-07-17 15:23:59', '2015-07-17 15:23:59'),
(57, 'Helen', 'Veski', '0000-00-00', 'helen_veski11@hotmail.com', '$2y$10$F9HLHy/3tuTDNVTMzYawtuRKmzjqyuKAEez9GOJfcftU9Vm2mn.hm', 0, '', '', '08:00', '20:00', '08:00', '18:00', '', '2015-07-20 12:00:37', '2015-07-20 12:00:37'),
(58, 'Triinu', 'Tamberg', '0000-00-00', 'triinu.tamberg@gmail.com', '$2y$10$Tz/2s7Ry1Glc1lI762bvYurhMZWDMB1nvjUg..476ir5.uETQ4z1q', 0, '', '', '08:00', '20:00', '08:00', '18:00', '', '2015-07-20 12:01:05', '2015-07-20 12:01:05'),
(59, 'Jüri-Karl', 'Leppik', '0000-00-00', 'jyrikarl@hotmail.com', '$2y$10$YGBmrzyFD6Ol18QOhlt6UOZb6Nf2j2Iw2rcwRxKOkQ9lKIEb.09uK', 0, '', '', '08:00', '20:00', '08:00', '18:00', '', '2015-07-20 12:16:45', '2015-07-20 12:16:45'),
(60, 'Kaili', 'Järvela', '0000-00-00', 'kaili.jarvela@gmail.com', '$2y$10$rUgzlMsgKsVPokCddM4UCO4/sxCHpLuT9k.cxhSLL0p6MGZj3xivK', 0, '', '', '08:00', '20:00', '08:00', '18:00', '', '2015-07-20 12:29:49', '2015-07-20 12:29:49'),
(61, 'Timmo', 'Tõnts', '0000-00-00', 'timmo.tonts@gmail.com', '$2y$10$LngK5C.7Ywb65Whe8HrF7O6Op6tWAz1x7uiMMxIh1dokt89Abta7u', 1, '2 years at IT college, I can fix a lot of problems', '', '08:00', '20:00', '08:00', '18:00', '', '2015-07-20 12:32:55', '2015-07-20 12:32:55'),
(87, 'Dana', 'Samhadaneh', '0000-00-00', 'Dana-samhadaneh@hotmail.com', '$2y$10$frA7VEmCRGWYizZuz5bdHeSFW4cbdPtKrmkGSSjeT2TiWJb6LmI1K', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-21 13:08:37', '2015-07-21 13:08:37'),
(88, 'Nourhan', 'ElKhatib', '0000-00-00', 'nelkhati@qatar.cmu.edu', '$2y$10$taaaDjqzNcSxCxxVsV6Y8.zzNcXny9qYag6bnKkVz93urWBQhJOAS', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-21 20:17:11', '2015-07-21 20:17:11'),
(89, 'Demo', 'Demo', '0000-00-00', 'fixnation@fixnation.co', '$2y$10$aS6bYPh/.I92Q2CBdxnLVOl6Yz1cz9JpduR7nSL2ZNBRlrKkehMxe', 0, '', '', '00:00', '00:00', '00:00', '00:00', 'd7Vf7JUyswsX6tAfiXZQmHv6pFg9ocxN59nADVmLosUHioqjFKFcm3ZLCpok', '2015-07-22 08:48:38', '2015-07-22 10:00:48'),
(90, 'Zanib', 'Khalid', '0000-00-00', 'zkhalid@qatar.cmu.edu', '$2y$10$4lmidzS3D6fgHl82JpkCXuIKDBZc6elZuOBeNS1H4sRwFwyQuV8We', 1, 'WIndows, printers, online services, android and iphone', 'user_46.jpg', '08:00', '20:00', '08:00', '18:00', '0kEyMBFVFq3NaI51DvfEAdpnF6vdfnEX87OaCdgZh3xf9Mw7OmqZlatL4Jjb', '2015-07-17 08:40:23', '2015-07-17 08:40:29'),
(94, 'Jüri-Mikk', 'Udam', '0000-00-00', 'jurimikk@hotmail.com', '$2y$10$nkTU2sXAoZhCVjgW4ChQZeT1h7YhdcvlYEVEXVvZhPMNHaz9EEofm', 1, 'I am confident with Macbooks and iOS, also with fixing printers and troubleshooting wifi routers.', 'user_94.jpg', '19:00', '21:30', '10:00', '13:00', '', '2015-07-22 10:16:06', '2015-07-22 10:16:52'),
(95, 'Siim', 'Siim', '0000-00-00', 'siim@scoro.com', '$2y$10$iXBInIsyhj4HTKJ2aieAr.XesG.k0RDK8VKlqBwJVyQU0lOfopszm', 1, 'I do computers', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-22 10:57:59', '2015-07-22 10:57:59'),
(96, 'Raul', 'Ruukel', '0000-00-00', 'raul@scoro.com', '$2y$10$zOTvJtAZAA6VXUoYClOLgeboh7U6065S7By./Tmw01lf9MueMWJCG', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-22 10:59:32', '2015-07-22 10:59:32'),
(97, 'Asso', 'Randma', '0000-00-00', 'asso@scoro.com', '$2y$10$csHoZvv4pQUrsZs/jvFC7Oh8jj4eOFKL3ywAzphaUPFVHvY2JlfLi', 1, 'Computers', '', '10:00', '16:00', '12:00', '16:00', '', '2015-07-22 11:01:02', '2015-07-22 11:01:02'),
(98, 'Mihkel', 'Reinart', '0000-00-00', 'mihkel@scoro.com', '$2y$10$1aC3YFKj4gEuRi5ndTmPnOrHrNdxXAk2BNlwrgTYl6ovN4gb0kwaC', 1, 'I''m great at configuring WIFI routers', '', '20:00', '21:00', '00:00', '00:00', 'NSB8HwZRDQmDMxHOOBW3JuKMUVQxoeJMq7gxCL8APpsEHVCoD4dLOBx4VYuW', '2015-07-22 11:02:48', '2015-07-22 11:16:07'),
(99, 'Maher', 'Khan', '0000-00-00', 'maher460@gmail.com', '$2y$10$3rw8niNXA.pdMI0eQj3fBOFgf0tDa3Pumj4gXg0o.tmtpsyWK5zzq', 1, 'laptops, desktops, servers, printers, smartphones, gadgets, software, hardware, setup and operating systems', 'user_99.jpg', '17:00', '20:00', '10:00', '22:00', 'yvoxC4ecDkmkQYYkqZlRpVUymdBHvsqL1Xqi4bFbP7kyABleqKUYyOtZRoyB', '2015-07-22 12:13:08', '2015-07-30 08:16:24'),
(100, 'Akib', 'Fahad', '0000-00-00', 'fahad.akibahmed@gmail.com', '$2y$10$rFL4VHpRXD4.SBSVK.dPH.aeKFcGTmzDBJVF2fs/GFoWeFGkBKJw2', 0, '', 'user_100.jpeg', '00:00', '00:00', '00:00', '00:00', '', '2015-07-22 12:49:14', '2015-07-22 12:49:14'),
(101, 'Daniel', 'Ehandi', '0000-00-00', 'daniel.ehandi@gmail.com', '$2y$10$p.cCpdsalPOTKyhjoBsLMetTF1dKQYNJUuVoClKaWr1U7gJoklHqu', 1, 'Aspen HYSYS\nMicrosoft Office', '', '17:00', '22:00', '11:00', '20:00', 'dESEQvWGVTP5p8mAYt521zHffCYYlkEZzSv9lG7se5zMszvDA39kNHH56GAg', '2015-07-22 14:43:37', '2015-07-22 14:43:43'),
(102, 'Wa', 'Mong', '0000-00-00', 'wamong1982@gmail.com', '$2y$10$hs5zjYuyODyw64GwhnYPnepSjMgb6wDHvKq2NEMWBtj7Qs7GR6WGu', 1, '• Operating Systems: Red Hat Enterprise Linux 6(RHEL), Windows Server (2008, 2003), Windows (7, Vista, XP, 2000, ME, 98/95), DOS, Mac OS.\n\n•  Hardware/Peripherals: Workstations (PC Assembling, Dissembling, Troubleshooting with Ckt level), Cable/DSL Modems, NAS technologies, Printers, Scanners, Modems, Laptops, Routers, Switches, Hubs, Network Interface Cards, Wireless Routers, HDD Repair & Disaster data recovery.\n\n•  REDHAT 6 (Linux): Configuring, Maintenance, Troubleshooting, Administration of the following servers/services (Professional/Advanced Level), DNS (bind, djbdns), Squid Proxy, Mail with Qmail and Postfix including antivirus/spam/script filters, Apache for web, NFS (Network File System), RAID, FreeNAS/NAS4Free, NTP (Time Server), FTP, VPN, Samba including Print/File server, Gateway/Router, IPTALBES firewall. Certification ID: 130-113-517. \n\n• Microsoft Administration: Active Directory, Group Policy, Network Monitoring, TCP/IP, DHCP, DNS, FTP, VPN, Microsoft Office. \n\n• Network Protocols: TCP/IP, Web Server, Mail Server, DHCP, DNS, HTTP, FTP, VPN, Bluetooth.\n\n• CISCO: Configuring, Maintenance, Troubleshooting, Administration of the: CISCO VLAN, LAYER-2, LAYER-3 Data Network.\n\n• Web & Programming Language: Adobe Dreamweaver CS6. FrontPage, Joomla, Wordpress, HTML, java Script. SQL, VB Studio, C++.\n\n• Additional Skills: Norton Antivirus, McAfee Antivirus, AVG Antivirus. Ethical Hacking (Key Logging & Phishing) \n', 'user_102.jpg', '10:00', '10:00', '11:30', '02:30', '', '2015-07-23 04:25:39', '2015-07-23 04:26:55'),
(103, 'Anas', 'Ubaid', '0000-00-00', 'anasubaid@live.com', '$2y$10$SrqJprgomC55ZxKWi6Y1KuCOJwRZEHhsG8QGN46nYseRYMlYpAC7.', 1, 'Troubleshooting software, hardware. Hardware assembly. Installing windows, OSX and other software. Setting up printers, small scale networking equipment (modems, routers etc.)', '', '07:00', '11:00', '00:00', '00:00', '', '2015-07-23 07:48:16', '2015-07-23 07:48:16'),
(104, 'Anoop', '4ur_help_in_qatar', '0000-00-00', 'techhelp.4u.qatar@gmail.com', '$2y$10$erj6eDYCTpIWk80wv70WBuhYe2zjNVJOiQ/rx2oH/wYDIP6fb13RS', 1, '* Windows Administration (Fresh or Re-installation of Windows Operating systems and software products\n* Up-gradation of hardware components \n* Setting up of emails and configuration of Outlook\n* Networking\n* Installation and configuration of Firewalls, Routers, Wireless Access Points.\n* Basic printer troubleshooting\n* Android , IOS, Windows Phone help \n* Website Designing\n', 'user_104.jpg', '19:00', '23:00', '09:00', '23:00', 'Q7dmIdZIOvbu1xcnW2mtQPdhzjMI5zGwIPGtE0EvXpVxZDQBG3pURlzgeam5', '2015-07-23 08:21:38', '2015-10-17 08:14:56'),
(105, 'Kristina', 'Lilleõis', '0000-00-00', 'kristina@scoro.com', '$2y$10$U9BL.osPALuf0U2RtWwcduR3m0PxZHF8ReuXm/azVB8ff6qOPsqDi', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-23 08:24:45', '2015-07-23 08:24:45'),
(106, 'Jan', 'Soovik', '0000-00-00', 'jansovik94@hot.ee', '$2y$10$RaUKxOeRmmzM2ebYKEdGDuXKfa2/DuXZ3Dym2u7Pz7s3On3gnom6a', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-23 08:40:30', '2015-07-23 08:40:30'),
(107, 'ShaikDanish', 'Ahmed', '0000-00-00', 'shaik_danish@yahoo.com', '$2y$10$yxPUx0G.wXjsakxM9Y1WCO/LDNYc1lExEcAOWAOn.3gFhzh1AfSnq', 1, 'Installing Windows,Linux, And MAC.\nInstalling Antivirus and Firewalls, Microsoft Office and All Other Applications In PC.\nTroubleshooting Windows Operations Systems, XP,Vista,Seven and 8 or 8.1\nMobile Phone Repairs, Installing Operating Systems In Android and Apple Devices,\nInstalling Application in Mobile Phones of Android and Apple.\nRemoving Virus, Recovering Lost Data- Deleted or Corrupted.\nConfiguring Network Devices  : Switches, Routers and Access point.\nCabling And Repairing Printers,Scanners, Telephone Systems PBX or Avaya Etc and Fax Machines.\nWifi 3g or 4g Routers and Many More.', 'user_107.jpg', '18:30', '23:00', '14:00', '23:30', '', '2015-07-23 09:10:58', '2015-07-23 09:11:30'),
(108, 'Lubomir', 'Sima', '0000-00-00', 'lubomir.sima@gmail.com', '$2y$10$37QthUIGVxOvorMn0Ijqc.5FoC0AVnUTQfruU2Bh24ujUuiX6/UkS', 1, 'Windows - across all knows versions, basic user problems, advanced/expert knowledge\nWindows Server 2008/2012\nMicrosoft Exchange 2010/2013\nMicrosoft Office - 2003-2013\nLInux/Ux\nHardware devices-firewalls, routers, switches, printers...etc\n', '', '18:00', '23:30', '10:00', '23:30', '', '2015-07-23 10:55:16', '2015-07-23 10:55:16'),
(109, 'Mubashshir', 'Ahmed', '0000-00-00', 'rationalspy@gmail.com', '$2y$10$7T9Eg.kDiWguedtaOv2pz.su1QHGSrpHVIeGXXt73w7fwJO9ZZH3O', 1, 'I could help you with Microsoft office package, reports/CV writing and could help you with all the possible ways to get a job in gulf, personal and life coaching, any social service after my office hours 8 am to 5 pm', 'user_109.JPG', '00:00', '00:00', '00:00', '00:00', '', '2015-07-23 11:20:27', '2015-07-23 11:30:38'),
(110, 'BIJU', 'JOY', '0000-00-00', 'BIJU.JOY@LIVE.COM', '$2y$10$egkySCmO7O7VakBo4B8/u.ypNkhV3cjD5aSgn8g29PeV.KAzo5f1K', 1, '-> Installation / Re-installation of computer software in windows & Apple OS \n-> Troubleshooting /Fixing the issues related to computer hardware & software in     Windows OS.\n-> Fixing printer related issues\n-> Configure the software / wireless internet\n-> Installation of software in Android application [ Mobile phones]\n-> Technically support provided over remote connection using Teamviewer\n-> 100% job satisfaction will be catered to the client\n-> MCSE certified', '', '16:00', '22:00', '09:30', '21:00', 'FmyeRo8QNH9jRJYGRWobNohQu8Ac5F8E5GiI47D7yApmOD8iRACugnjaHcjq', '2015-07-23 11:33:50', '2015-07-23 11:38:44'),
(111, 'rubeel', 'iqbal', '0000-00-00', 'rubeel@gmail.com', '$2y$10$sc.p36ykXYFCBBFAta.Yqunn6qc9.h/Uy.OHxz8jR1HUFlxSiTAj6', 1, 'Windows, Linux, servers, virtualization, vmware', '', '00:00', '23:30', '00:00', '23:30', '', '2015-07-23 13:03:27', '2015-07-23 13:03:27'),
(112, 'Rahul', 'Mistry', '0000-00-00', 'rahulbmistry@hotmail.com', '$2y$10$5fmdZUw2DMExQIiiGl5qK.ZxsWKTNRkO.AJ6y9b/OYX/OtnPB4MqK', 1, 'Any thing which can be fixed ', 'user_112.jpg', '11:00', '22:00', '13:00', '22:00', '', '2015-07-23 13:16:14', '2015-07-23 13:16:14'),
(113, 'Atif', 'AbdulRehman', '0000-00-00', 'atifabdulrehman@gmail.com', '$2y$10$.f4xy291staoFyYHCu9rsO4BDagg./ExPnNqJBYVgwzvrOrx.QTsW', 1, 'Any type of Computer Networks, Hardware, Software and Installation Issues.', 'user_113.jpg', '09:00', '20:00', '09:00', '20:00', '', '2015-07-23 17:55:49', '2015-07-23 17:55:49'),
(114, 'Mohamed', 'Elfadl', '0000-00-00', 'mohamid92@live.com', '$2y$10$FYvnr2IPntwcpDtCUBAXieQnKbX3hHm3Ih7t4K01kCziXJ9nD1/TK', 1, 'reinstalling windows , printers , troubleshooting pc problems  ', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-23 18:25:16', '2015-07-23 18:25:16'),
(115, 'Farhan', 'ul-haq', '0000-00-00', 'farhanulhaqa@gmail.com', '$2y$10$TKgpK7.AA/OlAJs8bUccjuTJRWwtXX93TnIAFa1cIpr1xw8brNb.2', 0, '', 'user_115.JPG', '00:00', '00:00', '00:00', '00:00', '', '2015-07-23 22:39:59', '2015-07-23 22:39:59'),
(116, 'Shafi', 'Mohamed', '0000-00-00', 'goosebery@gmail.com', '$2y$10$0Z4zM9jz.XuDCUjAT1tS/.J8TUCIw5M1934A11qhf1/rQ8M/juLLu', 0, '', '', '00:00', '00:00', '00:00', '00:00', '2nFs5jnGVoOEZ0tJBu0CjmHlPXTpZwM8bPf7ile0TVzeentd1zmlqf0pM2pN', '2015-07-24 05:31:20', '2015-07-24 05:33:51'),
(117, 'Helo', 'World', '0000-00-00', 'hello@myname.com', '$2y$10$v8VjsjX3qZErJIiiqXpBd.7BDdsKIq80.WAlbl2G8rrrkcdKN0n9q', 0, '', '', '00:00', '00:00', '00:00', '00:00', 'VT5ziBK9mjLSyBQhS39744TPF4MuMXU8WXSBdOn2ndtyX6O6vVO5SREOt1p7', '2015-07-24 09:54:47', '2015-07-24 09:55:25'),
(118, 'Rehman', 'Yousuf', '0000-00-00', 'rehmanyousuf@sabanciuniv.edu', '$2y$10$pko6f7i/Ot2t0xSxeCe.1uxqneGpm6sF4w56U9MpKVxrLkNatm9pe', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-24 11:40:08', '2015-07-24 11:40:08'),
(119, 'Dan', 'ORiordan', '0000-00-00', 'dan.oriordan@gmail.com', '$2y$10$QxDvqqxiP5qa5q6lTzKA3eRpxPJDgEujtgNMVFsbPrS.kA/ROGJ3C', 1, 'Anything apple I can fix', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-24 12:14:16', '2015-07-24 12:14:16'),
(120, 'Noor', 'UlAlam', '0000-00-00', 'helpdeskqatar@gmail.com', '$2y$10$xj3q7qYsm.pe/h9C0X5x5utx/HriRFNToLG3IKPVzx02S9eqz2RAy', 1, 'Computer Hardware, Network, Wireless, Webdesign, Security Camera, Access Control, Time attendance, Satellite, Public Addressing ', 'user_120.jpg', '00:00', '00:00', '00:00', '00:00', '', '2015-07-24 13:34:18', '2015-07-24 13:34:18'),
(121, 'Fahad', 'Yahoo', '0000-00-00', 'shaukatkhan888@yahoo.com', '$2y$10$Sbk6ZywdJUjLjSKSi5CDOukshRFOpIdqlVwQjH.Jkt0b3HYNHpg52', 1, ' Installing Antivirus and Firewalls, Microsoft Office and All Other Applications In PC. Troubleshooting Windows Operations Systems, XP,Vista,Seven and 8 or 8.1', '', '08:00', '20:00', '14:00', '23:00', 'zsJjwQ6Rx9J6CGnBWhaWDyfFsoSy1XtzRMDB0TFv2mZqQP5ytPqNot3CU6Cs', '2015-07-24 21:47:04', '2015-07-24 21:50:29'),
(122, 'Shaiju', 'Aboobacker', '0000-00-00', 'friend_shaiju@yahoo.com', '$2y$10$.j5NCzxolD1T8dhZKY0PFeBNMcUSxGN.Aulk5NCmeLb5oRcdZ.0UO', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-25 07:16:26', '2015-07-25 07:16:26'),
(123, 'Nashi', 'Backer', '0000-00-00', 'nashibacker@gmail.com', '$2y$10$HgAIivd/yMigIX23dOVN1Oiwa44nzNFEbaiSVH4GpHwnnhfOwIVoC', 1, 'Linux, Windows, Networking, Firewalls, Active Directory.', '', '18:00', '22:00', '18:00', '22:00', 'BeKLMp53yAfxeWnI9PmZMPCpLWzbaNTDz70cICdh3K1ECqZ3zJNBnAjlTKeB', '2015-07-25 13:54:16', '2015-07-25 13:54:57'),
(124, 'Amanda', 'Parker-Woods', '0000-00-00', 'Info@voucherclubs.com', '$2y$10$F44PFnxhFVTUFfBSWFtgJes1bmByKZYVMQPoU2doEQnOTAs1KmaM.', 0, '', '', '00:00', '00:00', '00:00', '00:00', 'WFN0htDilt1O0bwoPpKDDXnjAcVyZcbRpcf6A0nZ1jKI0huQgjbenUor8tWk', '2015-07-25 18:20:00', '2015-07-29 18:54:37'),
(125, 'Balaji', 'Alagusundaram', '0000-00-00', 'caption_try@yahoo.co.in', '$2y$10$mQui7chXWlTqN6vTCleVtubJVV9VuO8m4KZblWL7aUKyRq5H44lyC', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-26 08:26:20', '2015-07-26 08:26:20'),
(126, 'Mukul', 'Chandwani', '0000-00-00', 'mukul.chandwani@gmail.com', '$2y$10$0sPPUwbiyjdacKn0Dp2E0ekQ5JKKTJs.tHSRYGoAHt9EOVKosXVAa', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-26 09:04:29', '2015-07-26 09:04:29'),
(127, 'talal', 'nasser', '0000-00-00', 'do7a_2022@live.com', '$2y$10$i8J72qF/4yIlJyXyfMwQwOH5l1PgzQM2v7pKkYUE1WDRjJ.bDnsE2', 1, 'Install, repair, maintain and upgrade desktop and notebook computers as well as printers.\n\n\n\n\n	.\n\n\n	Operating Systems:Windows NT/2000 / XP / Vista / 7 / 8 & Ubuntu.\n	Microsoft Office 2007 and 2010.\n\n	Fine knowledge of most kinds of Anti- virus and their security levels.\n\n	Excellent data rescue / Back up skills\n.\n	PC and Operating system migration\n\n	Excellent DATA rescue skills.\n\n	Very good in marketing.\n\n	Good at trouble shooting technical problems.\n', 'user_127.jpg', '07:00', '23:30', '07:00', '23:30', '', '2015-07-26 22:05:55', '2015-07-26 22:05:55'),
(128, 'Babil', 'Moidunny', '0000-00-00', 'babilm@gmail.com', '$2y$10$qQdwIHMvNJloSYuEUtl3qOhhSLOWBfC.xIo0Rz0eXxIfYu74PAKta', 1, 'Expert in identifying, troubleshooting and resolving software issues for windows laptops / desktops, Apple and Android devices.\nIf required, can assist with facilitating a hardware based resolution, by liaising with appropriate vendors.\n', 'user_128.jpg', '18:30', '23:00', '10:00', '23:00', '', '2015-07-27 05:47:02', '2015-07-27 05:47:02'),
(129, 'kowshik', 'karmokar', '0000-00-00', 'kowshik143bd@gmail.com', '$2y$10$0Kl3hta/KRRelDwVdkvlWO3yItmw9IOeWuhOoLDvgOnuz6NizcXq6', 1, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-07-27 18:15:16', '2015-07-27 18:15:16'),
(130, 'SMAHMUD', 'SMAHMUD', '0000-00-00', 'smms.com.bd@gmail.com', '$2y$10$w8EtEhEoOzZA45N8S/Wd4e/FWw0xA.lAG6waKJ5ZbTWLRhkvL8Fym', 1, 'ELECTRICAL HOUSE WEARING,COMPUTER SERVICING,   ', 'user_130.jpg', '00:00', '00:00', '00:00', '00:00', '', '2015-07-28 08:44:15', '2015-07-28 08:46:37'),
(131, 'Sampriti', 'Jain', '0000-00-00', 'sampritj@qatar.cmu.edu', '$2y$10$1OvfCV3K4efhd8QU6Ik7S.u4zrCtHTkp0.3J4b0ufFRngH3PxSs.e', 0, '', '', '00:00', '00:00', '00:00', '00:00', 'cNIO2HV3r3YNl3NDsbXDzBWFdZ5cne1nizB6AzOEOzZGEYWIIKr0whWkCdAu', '2015-07-30 08:15:11', '2015-07-30 08:15:52'),
(132, 'MohammedTanvir', 'Hossain', '0000-00-00', 'tanvir.tech@yahoo.com', '$2y$10$jYOYOyssgaUDmAFJJBex0.WQAt5EpS9hpNLWvWqXhizstA0Y5fsMG', 1, 'I am a Network Administrator. Over 16 years of experience as a support service & network engineer. Software & hardware related problem solution, upgrading your Laptop, Desktop & Server. Network related device (router, access point & firewall etc.) problem solution and many more...\n\n                ***       Very much confident to solve your problem. Please Ask Me       ***\n\n*  Excellent experience and knowledge with designing, installing and implementing VMware products for virtualization.\n*  Planning, implementing and monitoring network infrastructure of servers (DNS, DHCP, File, FTP, Web & Application servers, workstations, router, switches and wireless access points; Installing, configuring, upgrading various IT systems like ADSL router, broadband router, barcode printer, scanner, access control, time attendance, magnetic or proximity card reader & other PC peripherals and various types of software.\n*  Capable of recovering data in accidental case like affected by virus, Hard disk reformatted etc\n', 'user_132.jpg', '00:00', '00:00', '00:00', '00:00', 'ouaQQgNn5yM5aKwJXprlrQOkfXJthPh5PRjeRqq3c5OdQVVV1WZ6WZhaSZYs', '2015-07-30 09:59:51', '2015-07-30 10:28:23'),
(133, 'Omar', 'AbuHassan', '0000-00-00', 'omar.h.abohassan@hotmail.com', '$2y$10$.4DqWVO6e7QV.wCksHB.TeOc1/iQqn9JRbr1ccCRp/lDJtv/pl27m', 0, '', '', '00:00', '00:00', '00:00', '00:00', 'itLnUDmGXnhNp3rLKTzENzJCXnEkOqGcNCNqtuTWcIDQu2rFUR5fxWTIyETI', '2015-08-02 10:42:20', '2015-08-02 11:01:10'),
(134, 'Yusuf', 'Masud', '0000-00-00', 'marthvader.ym@gmail.com', '$2y$10$9Jsf8T7a.M/gF3tA58K4bOgmqONpuzJJ8SjfCtL88CS5rilxp5ZfW', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-08-07 00:22:49', '2015-08-07 00:22:49'),
(135, 'drgdgdg', 'rgdgrdg', '0000-00-00', 'dgrdrg@hot.ee', '$2y$10$unrOBhumwvqEQqOIBOx9e.Deh6V3ApQ/9SZ0bgwt0/LG./ziDhwyC', 0, '', '', '00:00', '00:00', '00:00', '00:00', '', '2015-08-26 17:38:54', '2015-08-26 18:04:17'),
(136, 'test', 'test', '0000-00-00', 'karl@scoro.com', '$2y$10$QPrFlAqX/TO8abkqSw0R/.qp23cgGx/BkNgJ6VjMfTgO0TkEhChIa', 0, '', '', '', '', '', '', '', '2015-08-28 03:57:25', '2015-08-28 03:57:25'),
(137, 'Jasmir', 'Jez', '0000-00-00', 'jezqatar@gmail.com', '$2y$10$FlsZPKrFg3u1jeUZyjdkFOx0cur7vMDGvAjdV3uWhUYFI54twgGDC', 1, 'Expertise in Windows & Software, Android & iOS environments.  \nOver Eight years of experience in Tech Support role. \nGeneral & Hardware troubleshooting, Email setup, OS & Antivirus installation, printer & Scanner troubleshooting and more.', 'user_137.jpg', '', '', '', '', '', '2015-09-01 06:43:27', '2015-09-01 06:53:32'),
(138, 'Kumara', 'Badhuge', '0000-00-00', 'kbadhuge@yahoo.com', '$2y$10$pCNkt75jXzMOZZ3nSfNQQubATYfo5wou3Sa0RRfsYYPCJX.OwI9ia', 0, '', '', '', '', '', '', '5gmesrFtGvkOoikbMnZ1yiH9V7zZdUsN8USW8EQG1JFPWIlfwyit5dsx8Y4u', '2015-09-04 04:02:35', '2015-09-11 16:53:03'),
(139, 'Thankom', 'Mohan', '0000-00-00', 'thankom@gmail.com', '$2y$10$PaEbNGcT/ntDm9GwvOfUVe8OxRx6w8aulGj9/WPkKWzuxE7R0dSOC', 0, '', '', '', '', '', '', '', '2015-09-16 11:12:30', '2015-09-16 11:12:30'),
(140, 'Izhar', 'Sy', '0000-00-00', 'reachizhar@gmail.com', '$2y$10$Yhhg/k79dTCh4ZMtF0cOl.mu1iuWIk.Sp3Gg7UtXVOo455dQlEY5K', 1, 'setting up computers, printers, scanners, LAN, installing software, elementray computer use, MS office suite. ', '', '', '', '', '', '', '2015-10-26 07:26:45', '2015-10-26 07:26:45'),
(141, 'Dan', 'Hague', '0000-00-00', 'dhague@me.com', '$2y$10$bXN4KrKC3597dSs/nnaOj.aEJZXoL1nE6PeZhIPVnkgxYX2mmUAc.', 0, '', 'user_141.png', '', '', '', '', '', '2015-10-29 09:54:48', '2015-10-29 09:56:15'),
(142, 'TRS', 'rdgdg', '0000-00-00', 'karlsefsefs@scoro.com', '$2y$10$uivfT.174tifMzFSs4M1qOxwq9VYudcdF9HKcRxKmxAwRR5YZQDxG', 0, '', '', '', '', '', '', '', '2015-11-21 13:47:13', '2015-11-21 13:47:13'),
(143, 'rdiogjriognj', 'oinjopjnmop', '0000-00-00', 'kaur@fuckup.com', '$2y$10$scH5aSJuGrgfP7xt/DkJRO9RnMmpLPYrtW0.stAfos6U.yOrMfLli', 0, '', '', '', '', '', '', '', '2015-11-21 13:52:21', '2015-11-21 13:52:21'),
(144, 'Fatima', 'Mustafawi', '0000-00-00', 'Fatma.mustafawi@live.com', '$2y$10$iRDrGXBJ2xHaECk2WOFP9eGa2XOCYvW743eKZbXFFFyl0VT2M6aam', 0, '', '', '', '', '', '', '', '2015-11-25 16:08:25', '2015-11-25 16:08:25');



-- ---------------------------------------------------------
--
-- Table structure for table : `users_addresses`
--
-- ---------------------------------------------------------
CREATE TABLE `users_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `street` varchar(100) NOT NULL,
  `street_number` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `is_default` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_addresses`
--
INSERT INTO `users_addresses` (`id`, `user_id`, `street`, `street_number`, `city`, `state`, `country`, `zip`, `latitude`, `longitude`, `is_default`) VALUES
(34, 46, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31471290, 51.44195070, 0),
(35, 47, 'Al Intisar St', '', 'Doha', 'Doha', 'Qatar', '', 25.32555480, 51.52040890, 0),
(36, 48, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31013530, 51.44631650, 0),
(37, 49, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31013530, 51.44631650, 0),
(38, 50, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31013530, 51.44631650, 0),
(40, 53, '', '', 'الدوحة', 'الدوحة', 'Qatar', '', 25.33333330, 51.48333330, 0),
(41, 52, 'Al Duhail St', '', 'Doha', 'Doha', 'Qatar', '', 25.35483550, 51.46578250, 0),
(42, 56, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31934770, 51.43620810, 0),
(44, 55, '', '', '', '', '', '', 0.00000000, 0.00000000, 0),
(47, 54, '', '', 'Doha', 'Doha', 'Qatar', '', 25.28611100, 51.50416700, 0),
(48, 58, 'E. Vilde tee', 55, 'Tallinn', 'Harju maakond', 'Eesti', 13412, 59.40087010, 24.69058410, 0),
(49, 59, 'Sipelga', 2, 'Tallinn', 'Harju maakond', 'Estonia', 13423, 59.40602160, 24.70144680, 0),
(50, 60, 'J. Sütiste tee', '', 'Tallinn', 'Harju maakond', 'Eesti', '', 59.39755640, 24.68991200, 0),
(51, 61, 'J. Sütiste tee', '', 'Tallinn', 'Harju maakond', 'Eesti', '', 59.39755640, 24.68991200, 0),
(52, 76, 'Piibelehe', 5, 'Tallinn', 'Harju maakond', 'Estonia', 10618, 59.42754460, 24.67764300, 0),
(53, 78, '', '', '', '', '', '', 0.00000000, 0.00000000, 0),
(59, 87, 'Al Muhandiseen St', '', 'Doha', 'Doha', 'Qatar', '', 25.31883150, 51.50380930, 0),
(61, 88, '', '', '', '', 'Qatar', '', 25.35482600, 51.18388400, 0),
(63, 45, 'Metsa', '37a', 'Tallinn', 'Harju maakond', 'Estonia', 11618, 59.38105610, 24.68329180, 0),
(64, 89, 'Promenade des Anglais', 113, 'Nice', 'PACA', 'France', 06000, 43.69086580, 7.24544300, 0),
(65, 5, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31013530, 51.44631650, 0),
(66, 6, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31013530, 51.44631650, 0),
(68, 94, 'Roo', 27, 'Tallinn', 'Harju maakond', 'Estonia', 10320, 59.43825520, 24.71468890, 0),
(69, 96, 'Ahtri', '', 'Tallinn', 'Harju maakond', 'Estonia', 10151, 59.44015380, 24.75907840, 0),
(70, 98, '', '', 'Tallinn', 'Harju County', 'Estonia', '', 59.43696080, 24.75357460, 0),
(71, 51, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31471290, 51.44195070, 0),
(72, 99, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31013530, 51.44631650, 0),
(74, 100, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 25.31013530, 51.44631650, 0),
(77, 101, 'Ladybarn Ln', 33, 'Manchester', '', 'United Kingdom', 'M14 6NG', 53.44001680, -2.21416650, 0),
(78, 97, 'Ahtri', 12, 'Tallinn', 'Harju maakond', 'Estonia', 10151, 59.43917640, 24.76338840, 1),
(80, 102, '', '', 'Dhaka', 'Dhaka Division', 'Bangladesh', '', 0.00000000, 0.00000000, 0),
(81, 103, '', '', 'Doha', 'Al Rayyan', 'Qatar', '', 25.22582270, 51.45721210, 0),
(90, 107, '', '', '', '', '', '', 0.00000000, 0.00000000, 0),
(93, 109, '', '', 'Doha', 'Doha', 'Qatar', '', 0.00000000, 0.00000000, 0),
(96, 110, '', '', 'Doha', 'Doha', 'Qatar', '', 0.00000000, 0.00000000, 0),
(97, 104, '', '', 'Doha', 'Doha', 'Qatar', '', 0.00000000, 0.00000000, 0),
(98, 113, 'Al Asmakh St', '', 'Doha', 'Doha', 'Qatar', '', 25.28584560, 51.53092130, 0),
(99, 114, '', '', 'Doha', 'Doha', 'Qatar', '', 25.29160970, 51.53043680, 0),
(100, 116, '1st Main Rd', '49/22', 'Chennai', 'TN', 'India', 600020, 13.00752600, 80.25418500, 0),
(101, 117, '', '', 'Mannheim', 'BW', 'Germany', '', 49.48745920, 8.46603950, 0),
(102, 118, 'Sabancı Ünv.', '', '', 'İstanbul', 'Turkey', 34956, 40.89244770, 29.37687220, 0),
(103, 120, '', '', '', '', 'Qatar', '', 25.35482600, 51.18388400, 0),
(104, 121, '', '', 'Doha', 'Doha', 'Qatar', '', 25.29160970, 51.53043680, 0),
(105, 122, 'Al Rayyah St', '', 'Doha', 'Doha', 'Qatar', '', 25.25833830, 51.51823230, 0),
(106, 123, '', '', 'Doha', 'Doha', 'Qatar', '', 25.28611100, 51.50416700, 0),
(107, 127, 'Al Matar Al Qadeem St', '', 'Doha', 'Doha', 'Qatar', '', 25.25228980, 51.55657160, 0),
(108, 128, '', '', '', 'Al Rayyan', 'Qatar', '', 25.33258140, 51.44670930, 0),
(109, 44, 'Boulevard Edouard Herriot', 98, 'Nice', 'PACA', 'France', 06200, 0.00000000, 0.00000000, 0),
(110, 130, '', '', '', 'Khulna Division', 'Bangladesh', '', 0.00000000, 0.00000000, 0),
(111, 131, '', '', 'Ar-Rayyān', 'Al Rayyan', 'Qatar', '', 0.00000000, 0.00000000, 0),
(117, 132, '', '', 'Abu Dhabi', 'Abu Dhabi', 'United Arab Emirates', '', 0.00000000, 0.00000000, 0),
(118, 134, 'E Crescent Way', 1331, 'Chandler', 'AZ', 'United States', 85249, 0.00000000, 0.00000000, 0),
(119, 135, '', '', '', '', '', '', 0.00000000, 0.00000000, 0),
(120, 136, 'Metsa', '37a', 'Tallinn', 'Harju maakond', 'Estonia', 11618, 0.00000000, 0.00000000, 0),
(125, 137, '', '', 'Doha', '', 'Qatar', '', 0.00000000, 0.00000000, 0),
(126, 138, '', '', '', '', '', '', 0.00000000, 0.00000000, 0),
(127, 140, 'Ibn Seena Street', '', 'Doha', 'Doha', 'Qatar', '', 0.00000000, 0.00000000, 0),
(129, 141, '', '', 'Doha', 'Doha', 'Qatar', '', 0.00000000, 0.00000000, 0);



-- ---------------------------------------------------------
--
-- Table structure for table : `users_contact_means`
--
-- ---------------------------------------------------------
CREATE TABLE `users_contact_means` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `mean_id` int(11) NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users_contact_means`
--
INSERT INTO `users_contact_means` (`id`, `user_id`, `mean_id`, `value`, `is_default`) VALUES
(41, 46, 1, 0097466820033, 0),
(42, 47, 1, 0097466930377, 0),
(43, 48, 1, 0097450187832, 0),
(44, 49, 1, 0097433183168, 0),
(45, 50, 1, 0097433183168, 0),
(48, 53, 1, 50185529, 0),
(50, 52, 1, 0097455715664, 0),
(52, 56, 1, '+974 6632 6036', 0),
(54, 55, 1, +97466019738, 0),
(57, 54, 1, +97455169196, 0),
(58, 57, 1, 53491067, 0),
(59, 58, 1, +37256678285, 0),
(60, 59, 1, +37256916211, 0),
(61, 60, 1, '+372 55568581 ', 0),
(62, 61, 1, +37253329805, 0),
(68, 87, 1, '+974 33954589', 0),
(70, 88, 1, +97430157362, 0),
(72, 45, 1, +3725214387, 0),
(73, 89, 1, '+555 555 5555', 0),
(75, 94, 1, +37251940587, 0),
(76, 95, 1, 48521578, 0),
(77, 51, 1, 0675890473, 0),
(78, 99, 1, +97455921650, 0),
(80, 100, 1, +97433158670, 0),
(83, 101, 1, +37253314028, 0),
(85, 102, 1, 01815957111, 0),
(86, 103, 1, +97455867295, 0),
(88, 105, 1, 123456789, 0),
(92, 106, 1, 5187477, 0),
(98, 107, 1, 33085741, 0),
(101, 109, 1, 0097433193798, 0),
(104, 110, 1, +97477793582, 0),
(105, 111, 1, +97433188543, 0),
(106, 104, 1, +97470035071, 0),
(107, 112, 1, +97433644855, 0),
(108, 113, 1, 0097470062390, 0),
(109, 114, 1, +97430065929, 0),
(110, 115, 1, 66224999, 0),
(111, 116, 1, +919841446464, 0),
(112, 117, 1, +123456784, 0),
(113, 118, 1, '+92 332 2156812', 0),
(114, 119, 1, +33674653809, 0),
(115, 120, 1, +97470434145, 0),
(116, 121, 1, 0097470321997, 0),
(117, 122, 1, +97433357988, 0),
(118, 124, 1, '+974 33962631', 0),
(119, 125, 1, +97466837585, 0),
(120, 126, 1, 50395962, 0),
(121, 127, 1, +97477101993, 0),
(122, 128, 1, +97466543462, 0),
(123, 44, 1, +421911438831, 0),
(124, 129, 1, +8801913898570, 0),
(126, 130, 1, +8801703755055, 0),
(127, 131, 1, +9745634345, 0),
(133, 132, 1, +971505412852, 0),
(134, 133, 1, 33032336, 0),
(135, 134, 1, 4803195652, 0),
(137, 135, 1, 555, 0),
(138, 136, 1, 555, 0),
(143, 137, 1, +97433194590, 0),
(145, 138, 1, +97455920221, 0),
(146, 139, 1, +97455874344, 0),
(147, 140, 1, +97433620626, 0),
(149, 141, 1, '+974 7443 9035', 0),
(150, 142, 1, 6486, 0),
(151, 143, 1, 6684684, 0),
(152, 144, 1, +97430006662, 0);


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;